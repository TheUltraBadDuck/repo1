#pragma once

#include <iostream>

int GCD(int a, int b);